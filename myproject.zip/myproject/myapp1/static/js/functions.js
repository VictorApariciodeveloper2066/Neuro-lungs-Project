 // Selecciona el área de drop
 let dropArea = document.getElementById('drop-area');

 // Prevenir comportamientos por defecto para eventos de drag & drop
 ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
   dropArea.addEventListener(eventName, preventDefaults, false);
   document.body.addEventListener(eventName, preventDefaults, false);
 });

 function preventDefaults(e) {
   e.preventDefault();
   e.stopPropagation();
 }

 // Resaltar el área cuando se arrastra un archivo sobre ella
 ['dragenter', 'dragover'].forEach(eventName => {
   dropArea.addEventListener(eventName, () => dropArea.classList.add('highlight'), false);
 });
 ['dragleave', 'drop'].forEach(eventName => {
   dropArea.addEventListener(eventName, () => dropArea.classList.remove('highlight'), false);
 });

 // Manejar el evento drop
 dropArea.addEventListener('drop', handleDrop, false);

 function handleDrop(e) {
   let dt = e.dataTransfer;
   let files = dt.files;
   document.getElementById('image').files = files;
   handleFiles(files);
 }

 // Vista previa de imagen
 function previewImage(event) {
   const reader = new FileReader();
   reader.onload = function() {
     const preview = document.getElementById('imagePreview');
     preview.src = reader.result;
     preview.style.display = 'block';
   };
   reader.readAsDataURL(event.target.files[0]);
 }

 function handleFiles(files) {
   const file = files[0];
   if (file) {
     previewImage({ target: { files: [file] } });
   }
 }

 // Mostrar pantalla de carga
 function showLoading() {
   document.getElementById('loadingScreen').classList.remove('hidden');
 }
 